namespace CSharpLabs.Lab05.Core
{
    public record Service(string Name, int ServiceId);
}
